# Money Mint - Web Version

Money Mint is a smart expense tracker and budget manager.

## 🚀 How to Run

### Method 1: Instant Local Use (No installation needed)
1. Double-click `index.html` in your file browser (or right-click > Open With > Chrome / Edge / Safari / Firefox).
2. It runs immediately in any browser on Windows, Mac, Linux, Android, or iOS!
3. All transactions and budgets are securely saved to your browser's `localStorage`.

### Method 2: Deploy Free Online (Work Anytime, Anywhere)
You can host this website online for free so anyone can access it via a link:
- **GitHub Pages:**
  1. Upload `index.html` to a GitHub repository.
  2. Go to **Settings > Pages** and select the `main` branch.
  3. Your website link will be live at `https://your-username.github.io/repository-name`.
- **Vercel or Netlify:**
  1. Drag and drop this folder onto [vercel.com](https://vercel.com) or [netlify.com](https://netlify.com).
  2. You will instantly get a live `https://money-mint.vercel.app` URL.

## 🌟 Features
- **Dashboard:** Monthly total spending, budget utilization, daily average, and recent activity.
- **Expenses:** Filter by date, category, and payment method (UPI, Cash, Debit/Credit Card). Real-time search.
- **Analytics:** Spending breakdown by category and personalized financial insights.
- **Budgets:** Set global and category-specific spending limits with alert indicators.
- **Reports:** One-click CSV export (for Excel/Google Sheets) and JSON backup/restore.
- **Theme:** Automatic Light / Dark mode toggle.
