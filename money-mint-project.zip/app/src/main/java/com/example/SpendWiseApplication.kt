package com.example

import android.app.Application

class SpendWiseApplication : Application() {
    companion object {
        lateinit var instance: SpendWiseApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}
