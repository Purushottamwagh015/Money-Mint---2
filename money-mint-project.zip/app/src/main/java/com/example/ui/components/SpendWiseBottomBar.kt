package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppDestination
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.DarkNavy

@Composable
fun SpendWiseBottomBar(
    currentDestination: AppDestination,
    onNavigate: (AppDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = listOf(
        Triple(AppDestination.DASHBOARD, "Home", Icons.Default.Dashboard),
        Triple(AppDestination.MY_EXPENSES, "Expenses", Icons.Default.ReceiptLong),
        Triple(AppDestination.ADD_EXPENSE, "Add", Icons.Default.Add),
        Triple(AppDestination.ANALYTICS, "Analytics", Icons.Default.BarChart),
        Triple(AppDestination.BUDGETS, "Budgets", Icons.Default.AccountBalanceWallet)
    )

    NavigationBar(
        modifier = modifier.testTag("spendwise_bottom_bar"),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp
    ) {
        items.forEach { (dest, label, icon) ->
            val isSelected = currentDestination == dest
            val isAdd = dest == AppDestination.ADD_EXPENSE

            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(dest) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        modifier = Modifier.size(if (isAdd) 26.dp else 22.dp)
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 10.sp
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = BrandBlue,
                    selectedTextColor = BrandBlue,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    indicatorColor = BrandBlue.copy(alpha = 0.15f)
                ),
                modifier = Modifier.testTag("bottom_nav_${label.lowercase()}")
            )
        }
    }
}
