package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BudgetOverview
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.ColorDanger
import com.example.ui.theme.ColorSuccess
import com.example.ui.theme.ColorWarning
import com.example.ui.utils.FormatUtils

@Composable
fun SummaryCardItem(
    title: String,
    amountString: String,
    supportingText: String,
    icon: ImageVector,
    iconTint: Color,
    iconBgColor: Color,
    modifier: Modifier = Modifier,
    progress: Float? = null,
    trendText: String? = null,
    isPositiveTrend: Boolean = true,
    testTag: String = ""
) {
    Card(
        modifier = modifier
            .testTag(testTag)
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                RoundedCornerShape(14.dp)
            ),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            // Header Row: Title and Icon
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp
                    )
                )
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(iconBgColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Large Amount Value
            Text(
                text = amountString,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 26.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    letterSpacing = (-0.5).sp
                )
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Supporting row or progress bar
            if (progress != null) {
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { (progress / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = when {
                        progress > 95f -> ColorDanger
                        progress > 80f -> ColorWarning
                        else -> BrandBlue
                    },
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = supportingText,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                )

                if (trendText != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isPositiveTrend) Icons.Default.TrendingDown else Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = if (isPositiveTrend) ColorSuccess else ColorWarning,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = trendText,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (isPositiveTrend) ColorSuccess else ColorWarning,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SummaryCardsSection(
    budgetOverview: BudgetOverview,
    todayExpensesAmount: Double,
    todayTransactionsCount: Int,
    currencySymbol: String,
    modifier: Modifier = Modifier
) {
    FlowRow(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        maxItemsInEachRow = 4
    ) {
        // Card 1: Total Spent
        SummaryCardItem(
            title = "Total Spent",
            amountString = FormatUtils.formatCurrency(budgetOverview.totalSpent, currencySymbol),
            supportingText = "This month",
            icon = Icons.Default.ShowChart,
            iconTint = BrandBlue,
            iconBgColor = Color(0xFFE6F3FA),
            trendText = "-4.2% vs last month",
            isPositiveTrend = true,
            testTag = "card_total_spent",
            modifier = Modifier.weight(1f)
        )

        // Card 2: Today's Expenses
        SummaryCardItem(
            title = "Today's Expenses",
            amountString = FormatUtils.formatCurrency(todayExpensesAmount, currencySymbol),
            supportingText = "$todayTransactionsCount transactions today",
            icon = Icons.Default.CalendarToday,
            iconTint = Color(0xFF25A56A),
            iconBgColor = Color(0xFFE8F6EF),
            testTag = "card_today_expenses",
            modifier = Modifier.weight(1f)
        )

        // Card 3: Monthly Budget
        SummaryCardItem(
            title = "Monthly Budget",
            amountString = FormatUtils.formatCurrency(budgetOverview.totalBudget, currencySymbol),
            supportingText = "${String.format(java.util.Locale.US, "%.1f", budgetOverview.percentUsed)}% used",
            progress = budgetOverview.percentUsed,
            icon = Icons.Default.AccountBalanceWallet,
            iconTint = Color(0xFFE4A72C),
            iconBgColor = Color(0xFFFDF6E9),
            testTag = "card_monthly_budget",
            modifier = Modifier.weight(1f)
        )

        // Card 4: Remaining Budget
        SummaryCardItem(
            title = "Remaining Budget",
            amountString = FormatUtils.formatCurrency(budgetOverview.remainingBudget, currencySymbol),
            supportingText = "Available this month",
            icon = Icons.Default.Savings,
            iconTint = if (budgetOverview.remainingBudget < 5000) ColorDanger else Color(0xFF6C5CE7),
            iconBgColor = if (budgetOverview.remainingBudget < 5000) Color(0xFFFBECEC) else Color(0xFFF0EDFD),
            testTag = "card_remaining_budget",
            modifier = Modifier.weight(1f)
        )
    }
}
