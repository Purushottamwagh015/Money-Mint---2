package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DateRangeFilter
import com.example.data.model.Expense
import com.example.data.model.ExpenseCategory
import com.example.ui.components.ExpenseTable

@Composable
fun ExpensesScreen(
    expenses: List<Expense>,
    categories: List<ExpenseCategory>,
    currencySymbol: String,
    selectedCategory: String?,
    onSelectCategory: (String?) -> Unit,
    selectedStatus: String?,
    onSelectStatus: (String?) -> Unit,
    selectedDateRange: DateRangeFilter,
    onSelectDateRange: (DateRangeFilter) -> Unit,
    onAddExpense: () -> Unit,
    onExportCsv: () -> Unit,
    onViewExpense: (Expense) -> Unit,
    onEditExpense: (Expense) -> Unit,
    onDeleteExpense: (Expense) -> Unit,
    isCompactScreen: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = "My Expenses",
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 24.sp
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Track, search, and manage all your daily financial transactions.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            )
        }

        ExpenseTable(
            expenses = expenses,
            categories = categories,
            currencySymbol = currencySymbol,
            selectedCategory = selectedCategory,
            onSelectCategory = onSelectCategory,
            selectedStatus = selectedStatus,
            onSelectStatus = onSelectStatus,
            selectedDateRange = selectedDateRange,
            onSelectDateRange = onSelectDateRange,
            onAddExpense = onAddExpense,
            onExportCsv = onExportCsv,
            onViewExpense = onViewExpense,
            onEditExpense = onEditExpense,
            onDeleteExpense = onDeleteExpense,
            isCompactScreen = isCompactScreen,
            title = "All Transactions"
        )
    }
}
