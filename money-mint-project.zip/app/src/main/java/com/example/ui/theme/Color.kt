package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SpendWise Brand Color System
val BrandBlue = Color(0xFF0878B8)
val BrandBlueDark = Color(0xFF065A8C)
val BrandBlueLight = Color(0xFFE6F3FA)
val BrandBlueSubtle = Color(0xFFD0E8F5)

val DarkNavy = Color(0xFF17232B)
val DarkNavySurface = Color(0xFF1F2E38)
val DarkNavyBorder = Color(0xFF2A3C47)

val BgLight = Color(0xFFF5F7F9)
val SurfaceWhite = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF18232D)
val TextSecondary = Color(0xFF687580)
val BorderSubtle = Color(0xFFDCE3E8)

val ColorSuccess = Color(0xFF25A56A)
val ColorSuccessBg = Color(0xFFE8F6EF)
val ColorWarning = Color(0xFFE4A72C)
val ColorWarningBg = Color(0xFFFDF6E9)
val ColorDanger = Color(0xFFD9534F)
val ColorDangerBg = Color(0xFFFBECEC)

// Dark theme colors
val DarkBg = Color(0xFF0F171C)
val DarkSurface = Color(0xFF17232B)
val DarkCard = Color(0xFF1C2A34)
val DarkTextPrimary = Color(0xFFF0F4F8)
val DarkTextSecondary = Color(0xFF9BA8B4)
val DarkBorder = Color(0xFF283844)
