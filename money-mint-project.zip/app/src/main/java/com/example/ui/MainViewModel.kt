package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.BudgetOverview
import com.example.data.model.CategorySummary
import com.example.data.model.DateRangeFilter
import com.example.data.model.Expense
import com.example.data.model.ExpenseCategory
import com.example.data.model.ExpenseStatus
import com.example.data.model.PaymentMethod
import com.example.data.repository.ExpenseRepository
import com.example.data.repository.UserPreferencesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

enum class AppDestination(val label: String) {
    DASHBOARD("Dashboard"),
    ADD_EXPENSE("Add Expense"),
    MY_EXPENSES("My Expenses"),
    CATEGORIES("Categories"),
    ANALYTICS("Analytics"),
    BUDGETS("Budgets"),
    REPORTS("Reports"),
    SETTINGS("Settings")
}

enum class ChartPeriod(val label: String) {
    TODAY("Today"),
    THIS_WEEK("This Week"),
    THIS_MONTH("This Month"),
    THIS_YEAR("This Year")
}

data class SpendingBarData(
    val label: String,
    val amount: Double,
    val isSelected: Boolean = false
)

data class SpendWiseUiState(
    val isLoggedIn: Boolean = false,
    val currentDestination: AppDestination = AppDestination.DASHBOARD,
    val searchQuery: String = "",
    val selectedCategoryFilter: String? = "All",
    val selectedStatusFilter: String? = "All",
    val selectedDateRange: DateRangeFilter = DateRangeFilter.ALL,
    val selectedChartPeriod: ChartPeriod = ChartPeriod.THIS_WEEK,
    val expenses: List<Expense> = emptyList(),
    val filteredExpenses: List<Expense> = emptyList(),
    val categories: List<ExpenseCategory> = emptyList(),
    val todayExpensesAmount: Double = 1240.0,
    val todayTransactionsCount: Int = 5,
    val budgetOverview: BudgetOverview = BudgetOverview(40000.0, 24680.0, 15320.0, 61.7f),
    val categorySummaries: List<CategorySummary> = emptyList(),
    val spendingChartData: List<SpendingBarData> = emptyList(),
    val userName: String = "Purushottam Wagh",
    val userEmail: String = "purushottamwagh016@gmail.com",
    val currencySymbol: String = "₹",
    val themeMode: String = "light",
    val budgetAlerts: Boolean = true,
    val dailyReminders: Boolean = true,
    val monthlySummaries: Boolean = true
)

class MainViewModel(
    application: Application,
    private val expenseRepository: ExpenseRepository,
    private val userPreferences: UserPreferencesRepository
) : AndroidViewModel(application) {

    class Factory(
        private val expenseRepository: ExpenseRepository,
        private val userPreferences: UserPreferencesRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val app = com.example.SpendWiseApplication.instance
            return MainViewModel(app, expenseRepository, userPreferences) as T
        }
    }

    init {
        viewModelScope.launch {
            expenseRepository.initializeIfNeeded()
        }
    }

    // Navigation Destination
    private val _currentDestination = MutableStateFlow(AppDestination.DASHBOARD)
    val currentDestination: StateFlow<AppDestination> = _currentDestination.asStateFlow()

    fun onNavigate(destination: AppDestination) {
        _currentDestination.value = destination
    }

    // Header Search Query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Expenses Filters
    private val _categoryFilter = MutableStateFlow<String?>("All")
    val categoryFilter: StateFlow<String?> = _categoryFilter.asStateFlow()

    private val _statusFilter = MutableStateFlow<String?>("All")
    val statusFilter: StateFlow<String?> = _statusFilter.asStateFlow()

    private val _dateRangeFilter = MutableStateFlow(DateRangeFilter.ALL)
    val dateRangeFilter: StateFlow<DateRangeFilter> = _dateRangeFilter.asStateFlow()

    fun filterByCategory(category: String?) {
        _categoryFilter.value = category
    }

    fun filterByStatus(status: String?) {
        _statusFilter.value = status
    }

    fun setDateRangeFilter(filter: DateRangeFilter) {
        _dateRangeFilter.value = filter
    }

    // Spending Overview Chart Period
    private val _chartPeriod = MutableStateFlow(ChartPeriod.THIS_WEEK)
    val chartPeriod: StateFlow<ChartPeriod> = _chartPeriod.asStateFlow()

    fun setChartPeriod(period: ChartPeriod) {
        _chartPeriod.value = period
    }

    // Repository flows
    val allExpenses = expenseRepository.allExpenses
    val allCategories = expenseRepository.allCategories

    // User preferences flows
    val userName = userPreferences.userName
    val userEmail = userPreferences.userEmail
    val currencySymbol = userPreferences.currencySymbol
    val monthlyBudget = userPreferences.monthlyBudget
    val themeMode = userPreferences.themeMode
    val budgetAlerts = userPreferences.budgetAlerts
    val dailyReminders = userPreferences.dailyReminders
    val monthlySummaries = userPreferences.monthlySummaries
    val isLoggedIn = userPreferences.isLoggedIn

    // Filtered expenses list flow
    val filteredExpenses = combine(
        allExpenses,
        _searchQuery,
        _categoryFilter,
        _statusFilter,
        _dateRangeFilter
    ) { expenses, query, cat, status, dateFilter ->
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()

        expenses.filter { expense ->
            val matchesQuery = query.isBlank() ||
                expense.title.contains(query, ignoreCase = true) ||
                expense.category.contains(query, ignoreCase = true) ||
                expense.notes.contains(query, ignoreCase = true) ||
                expense.paymentMethod.displayName.contains(query, ignoreCase = true)

            val matchesCategory = cat.isNullOrBlank() || cat == "All" || expense.category.equals(cat, ignoreCase = true)
            val matchesStatus = status.isNullOrBlank() || status == "All" || expense.status.displayName.equals(status, ignoreCase = true)

            val matchesDate = when (dateFilter) {
                DateRangeFilter.ALL -> true
                DateRangeFilter.TODAY -> {
                    val expCal = Calendar.getInstance().apply { timeInMillis = expense.dateMillis }
                    cal.get(Calendar.YEAR) == expCal.get(Calendar.YEAR) &&
                        cal.get(Calendar.DAY_OF_YEAR) == expCal.get(Calendar.DAY_OF_YEAR)
                }
                DateRangeFilter.THIS_WEEK -> {
                    val expCal = Calendar.getInstance().apply { timeInMillis = expense.dateMillis }
                    cal.get(Calendar.YEAR) == expCal.get(Calendar.YEAR) &&
                        cal.get(Calendar.WEEK_OF_YEAR) == expCal.get(Calendar.WEEK_OF_YEAR)
                }
                DateRangeFilter.THIS_MONTH -> {
                    val expCal = Calendar.getInstance().apply { timeInMillis = expense.dateMillis }
                    cal.get(Calendar.YEAR) == expCal.get(Calendar.YEAR) &&
                        cal.get(Calendar.MONTH) == expCal.get(Calendar.MONTH)
                }
                DateRangeFilter.LAST_30_DAYS -> {
                    expense.dateMillis >= (now - 30L * 24 * 60 * 60 * 1000)
                }
                DateRangeFilter.THIS_YEAR -> {
                    val expCal = Calendar.getInstance().apply { timeInMillis = expense.dateMillis }
                    cal.get(Calendar.YEAR) == expCal.get(Calendar.YEAR)
                }
            }

            matchesQuery && matchesCategory && matchesStatus && matchesDate
        }
    }

    // Chart Data Flow
    val spendingChartData = combine(allExpenses, _chartPeriod) { expenses, period ->
        val cal = Calendar.getInstance()
        when (period) {
            ChartPeriod.TODAY -> {
                val slots = listOf("8 AM", "11 AM", "2 PM", "5 PM", "8 PM", "11 PM")
                val amounts = mutableMapOf<String, Double>()
                slots.forEach { amounts[it] = 0.0 }
                expenses.forEach { exp ->
                    val expCal = Calendar.getInstance().apply { timeInMillis = exp.dateMillis }
                    if (cal.get(Calendar.YEAR) == expCal.get(Calendar.YEAR) &&
                        cal.get(Calendar.DAY_OF_YEAR) == expCal.get(Calendar.DAY_OF_YEAR)
                    ) {
                        val hour = expCal.get(Calendar.HOUR_OF_DAY)
                        val slot = when {
                            hour < 10 -> "8 AM"
                            hour < 13 -> "11 AM"
                            hour < 16 -> "2 PM"
                            hour < 19 -> "5 PM"
                            hour < 22 -> "8 PM"
                            else -> "11 PM"
                        }
                        amounts[slot] = (amounts[slot] ?: 0.0) + exp.amount
                    }
                }
                slots.map { SpendingBarData(label = it, amount = amounts[it] ?: 0.0) }
            }
            ChartPeriod.THIS_WEEK -> {
                val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                val amounts = mutableMapOf<String, Double>()
                days.forEach { amounts[it] = 0.0 }
                expenses.forEach { exp ->
                    val expCal = Calendar.getInstance().apply { timeInMillis = exp.dateMillis }
                    if (cal.get(Calendar.YEAR) == expCal.get(Calendar.YEAR) &&
                        cal.get(Calendar.WEEK_OF_YEAR) == expCal.get(Calendar.WEEK_OF_YEAR)
                    ) {
                        val dayOfWeek = when (expCal.get(Calendar.DAY_OF_WEEK)) {
                            Calendar.MONDAY -> "Mon"
                            Calendar.TUESDAY -> "Tue"
                            Calendar.WEDNESDAY -> "Wed"
                            Calendar.THURSDAY -> "Thu"
                            Calendar.FRIDAY -> "Fri"
                            Calendar.SATURDAY -> "Sat"
                            Calendar.SUNDAY -> "Sun"
                            else -> "Mon"
                        }
                        amounts[dayOfWeek] = (amounts[dayOfWeek] ?: 0.0) + exp.amount
                    }
                }
                days.map { SpendingBarData(label = it, amount = amounts[it] ?: 0.0) }
            }
            ChartPeriod.THIS_MONTH -> {
                val weeks = listOf("Week 1", "Week 2", "Week 3", "Week 4")
                val amounts = mutableMapOf<String, Double>()
                weeks.forEach { amounts[it] = 0.0 }
                expenses.forEach { exp ->
                    val expCal = Calendar.getInstance().apply { timeInMillis = exp.dateMillis }
                    if (cal.get(Calendar.YEAR) == expCal.get(Calendar.YEAR) &&
                        cal.get(Calendar.MONTH) == expCal.get(Calendar.MONTH)
                    ) {
                        val day = expCal.get(Calendar.DAY_OF_MONTH)
                        val slot = when {
                            day <= 7 -> "Week 1"
                            day <= 14 -> "Week 2"
                            day <= 21 -> "Week 3"
                            else -> "Week 4"
                        }
                        amounts[slot] = (amounts[slot] ?: 0.0) + exp.amount
                    }
                }
                weeks.map { SpendingBarData(label = it, amount = amounts[it] ?: 0.0) }
            }
            ChartPeriod.THIS_YEAR -> {
                val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
                val amounts = mutableMapOf<String, Double>()
                months.forEach { amounts[it] = 0.0 }
                expenses.forEach { exp ->
                    val expCal = Calendar.getInstance().apply { timeInMillis = exp.dateMillis }
                    if (cal.get(Calendar.YEAR) == expCal.get(Calendar.YEAR)) {
                        val monthName = months[expCal.get(Calendar.MONTH)]
                        amounts[monthName] = (amounts[monthName] ?: 0.0) + exp.amount
                    }
                }
                months.map { SpendingBarData(label = it, amount = amounts[it] ?: 0.0) }
            }
        }
    }

    // Today's summary flow
    val todaySummary = allExpenses.combine(monthlyBudget) { expenses, _ ->
        val cal = Calendar.getInstance()
        val todayExpenses = expenses.filter {
            val expCal = Calendar.getInstance().apply { timeInMillis = it.dateMillis }
            cal.get(Calendar.YEAR) == expCal.get(Calendar.YEAR) &&
                cal.get(Calendar.DAY_OF_YEAR) == expCal.get(Calendar.DAY_OF_YEAR)
        }
        val total = todayExpenses.sumOf { it.amount }
        Pair(total, todayExpenses.size)
    }

    // Budget Overview flow
    val budgetOverview = combine(allExpenses, monthlyBudget) { expenses, budget ->
        val cal = Calendar.getInstance()
        val currentMonthExpenses = expenses.filter {
            val expCal = Calendar.getInstance().apply { timeInMillis = it.dateMillis }
            cal.get(Calendar.YEAR) == expCal.get(Calendar.YEAR) &&
                cal.get(Calendar.MONTH) == expCal.get(Calendar.MONTH)
        }
        val totalSpent = currentMonthExpenses.sumOf { it.amount }
        val remaining = maxOf(0.0, budget - totalSpent)
        val percent = if (budget > 0) ((totalSpent / budget) * 100).toFloat() else 0f
        BudgetOverview(
            totalBudget = budget,
            totalSpent = totalSpent,
            remainingBudget = remaining,
            percentUsed = percent
        )
    }

    // Category breakdown summaries flow
    val categoryBreakdown = combine(allExpenses, allCategories) { expenses, categories ->
        val cal = Calendar.getInstance()
        val currentMonthExpenses = expenses.filter {
            val expCal = Calendar.getInstance().apply { timeInMillis = it.dateMillis }
            cal.get(Calendar.YEAR) == expCal.get(Calendar.YEAR) &&
                cal.get(Calendar.MONTH) == expCal.get(Calendar.MONTH)
        }
        val totalMonthSpent = currentMonthExpenses.sumOf { it.amount }

        categories.map { category ->
            val catExpenses = currentMonthExpenses.filter { it.category.equals(category.name, ignoreCase = true) }
            val catTotal = catExpenses.sumOf { it.amount }
            val percentage = if (totalMonthSpent > 0) ((catTotal / totalMonthSpent) * 100).toFloat() else 0f
            CategorySummary(
                categoryName = category.name,
                iconKey = category.iconKey,
                colorHex = category.colorHex,
                totalAmount = catTotal,
                percentage = percentage,
                transactionCount = catExpenses.size,
                budget = category.monthlyBudget
            )
        }.sortedByDescending { it.totalAmount }
    }

    // Combined UI state
    val uiState: StateFlow<SpendWiseUiState> = combine(
        combine(_currentDestination, _searchQuery, _categoryFilter, _statusFilter, _dateRangeFilter) { dest, query, cat, status, dateRange ->
            Tuple5(dest, query, cat, status, dateRange)
        },
        combine(_chartPeriod, allExpenses, filteredExpenses, allCategories, todaySummary) { period, expenses, filtered, cats, today ->
            Tuple5(period, expenses, filtered, cats, today)
        },
        combine(budgetOverview, categoryBreakdown, spendingChartData) { budget, breakdown, chart ->
            Triple(budget, breakdown, chart)
        },
        combine(userName, userEmail, currencySymbol, themeMode, isLoggedIn) { name, email, symbol, theme, loggedIn ->
            Tuple5(name, email, symbol, theme, loggedIn)
        },
        combine(budgetAlerts, dailyReminders, monthlySummaries) { alerts, reminders, summaries ->
            Triple(alerts, reminders, summaries)
        }
    ) { (dest, query, cat, status, dateRange), (period, expenses, filtered, cats, today), (budget, breakdown, chart), (name, email, symbol, theme, loggedIn), (alerts, reminders, summaries) ->
        SpendWiseUiState(
            isLoggedIn = loggedIn,
            currentDestination = dest,
            searchQuery = query,
            selectedCategoryFilter = cat,
            selectedStatusFilter = status,
            selectedDateRange = dateRange,
            selectedChartPeriod = period,
            expenses = expenses,
            filteredExpenses = filtered,
            categories = cats,
            todayExpensesAmount = today.first,
            todayTransactionsCount = today.second,
            budgetOverview = budget,
            categorySummaries = breakdown,
            spendingChartData = chart,
            userName = name,
            userEmail = email,
            currencySymbol = symbol,
            themeMode = theme,
            budgetAlerts = alerts,
            dailyReminders = reminders,
            monthlySummaries = summaries
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SpendWiseUiState()
    )

    fun login(email: String, name: String) {
        userPreferences.login(email, name)
    }

    fun register(name: String, email: String, currency: String) {
        userPreferences.register(name, email, currency)
    }

    fun logout() {
        userPreferences.logout()
    }

    // Action handlers
    fun saveExpense(
        id: Long,
        title: String,
        amount: Double,
        category: String,
        dateMillis: Long,
        paymentMethod: PaymentMethod,
        status: ExpenseStatus,
        notes: String
    ) {
        viewModelScope.launch {
            if (id == 0L) {
                expenseRepository.addExpense(
                    Expense(
                        title = title,
                        amount = amount,
                        category = category,
                        dateMillis = dateMillis,
                        paymentMethod = paymentMethod,
                        status = status,
                        notes = notes
                    )
                )
            } else {
                expenseRepository.updateExpense(
                    Expense(
                        id = id,
                        title = title,
                        amount = amount,
                        category = category,
                        dateMillis = dateMillis,
                        paymentMethod = paymentMethod,
                        status = status,
                        notes = notes
                    )
                )
            }
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            expenseRepository.deleteExpense(expense.id)
        }
    }

    fun updateMonthlyBudget(newBudget: Double) {
        viewModelScope.launch {
            userPreferences.updateMonthlyBudget(newBudget)
        }
    }

    fun saveCategory(
        id: Long,
        name: String,
        iconKey: String,
        colorHex: String,
        budget: Double
    ) {
        viewModelScope.launch {
            if (id == 0L) {
                expenseRepository.addCategory(
                    ExpenseCategory(
                        name = name,
                        iconKey = iconKey,
                        colorHex = colorHex,
                        monthlyBudget = budget,
                        isCustom = true
                    )
                )
            } else {
                expenseRepository.updateCategory(
                    ExpenseCategory(
                        id = id,
                        name = name,
                        iconKey = iconKey,
                        colorHex = colorHex,
                        monthlyBudget = budget,
                        isCustom = true
                    )
                )
            }
        }
    }

    fun deleteCategory(category: ExpenseCategory) {
        viewModelScope.launch {
            expenseRepository.deleteCategory(category.id)
        }
    }

    fun updateProfile(name: String, email: String) {
        userPreferences.updateProfile(name, email)
    }

    fun updateCurrency(symbol: String) {
        userPreferences.updateCurrency(symbol)
    }

    fun toggleTheme() {
        val current = userPreferences.themeMode.value
        val next = if (current == "dark") "light" else "dark"
        userPreferences.updateThemeMode(next)
    }

    fun updateNotifications(alerts: Boolean, daily: Boolean, monthly: Boolean) {
        userPreferences.updateNotificationSettings(alerts, daily, monthly)
    }

    fun resetSampleData() {
        viewModelScope.launch {
            expenseRepository.resetToSampleData()
            userPreferences.updateMonthlyBudget(40000.0)
        }
    }

    fun exportCsv(): String {
        return expenseRepository.exportToCsv(uiState.value.expenses, uiState.value.currencySymbol)
    }
}

data class Tuple4<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)
data class Tuple5<A, B, C, D, E>(val a: A, val b: B, val c: C, val d: D, val e: E)
