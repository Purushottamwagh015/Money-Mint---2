package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppDestination
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.DarkNavy
import com.example.ui.theme.DarkNavyBorder

data class NavItemSpec(
    val destination: AppDestination,
    val title: String,
    val icon: ImageVector
)

val NAV_ITEMS = listOf(
    NavItemSpec(AppDestination.DASHBOARD, "Dashboard", Icons.Default.Dashboard),
    NavItemSpec(AppDestination.ADD_EXPENSE, "Add Expense", Icons.Default.AddCircle),
    NavItemSpec(AppDestination.MY_EXPENSES, "My Expenses", Icons.Default.ReceiptLong),
    NavItemSpec(AppDestination.CATEGORIES, "Categories", Icons.Default.Category),
    NavItemSpec(AppDestination.ANALYTICS, "Analytics", Icons.Default.BarChart),
    NavItemSpec(AppDestination.BUDGETS, "Budgets", Icons.Default.AccountBalanceWallet),
    NavItemSpec(AppDestination.REPORTS, "Reports", Icons.AutoMirrored.Filled.InsertDriveFile),
    NavItemSpec(AppDestination.SETTINGS, "Settings", Icons.Default.Settings)
)

@Composable
fun SpendWiseSidebar(
    currentDestination: AppDestination,
    userName: String,
    userEmail: String,
    onNavigate: (AppDestination) -> Unit,
    modifier: Modifier = Modifier,
    onLogout: (() -> Unit)? = null
) {
    var showLogoPublishDialog by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier
            .width(250.dp)
            .fillMaxHeight(),
        color = DarkNavy,
        contentColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
            ) {
                // Brand Header with Official Money Mint Logo
                MoneyMintLogo(
                    size = 42.dp,
                    showText = true,
                    subtitle = "Financial Intelligence",
                    onClick = { showLogoPublishDialog = true },
                    modifier = Modifier.padding(vertical = 6.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = DarkNavyBorder, thickness = 1.dp)
                Spacer(modifier = Modifier.height(16.dp))

                // Navigation Items
                NAV_ITEMS.forEach { item ->
                    val isActive = currentDestination == item.destination
                    val isAction = item.destination == AppDestination.ADD_EXPENSE

                    val backgroundColor = when {
                        isActive -> Color(0xFF1E3444)
                        isAction -> Color(0x1A0878B8)
                        else -> Color.Transparent
                    }
                    val contentColor = when {
                        isActive -> Color.White
                        isAction -> Color(0xFF38B6FF)
                        else -> Color(0xFFB0BFC9)
                    }
                    val iconTint = when {
                        isActive -> BrandBlue
                        isAction -> Color(0xFF38B6FF)
                        else -> Color(0xFF7D91A0)
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(backgroundColor)
                            .clickable { onNavigate(item.destination) }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                            .testTag("nav_item_${item.destination.name.lowercase()}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.title,
                            tint = iconTint,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = contentColor,
                                fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Medium,
                                fontSize = 14.sp
                            )
                        )
                        if (isActive) {
                            Spacer(modifier = Modifier.weight(1f))
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(BrandBlue)
                            )
                        }
                    }
                }
            }

            // Bottom Profile Card & Publish Button
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF00B894).copy(alpha = 0.15f))
                        .clickable { showLogoPublishDialog = true }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("sidebar_publish_btn"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Public,
                        contentDescription = null,
                        tint = Color(0xFF00B894),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Publish & Share",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFF55EFC4),
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = DarkNavyBorder, thickness = 1.dp)
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF1E2E38))
                        .clickable { onNavigate(AppDestination.SETTINGS) }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(BrandBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userName.take(2).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = userName,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            maxLines = 1
                        )
                        Text(
                            text = "Pro Account",
                            color = Color(0xFF25A56A),
                            fontWeight = FontWeight.Normal,
                            fontSize = 11.sp
                        )
                    }
                    if (onLogout != null) {
                        IconButton(
                            onClick = onLogout,
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("sidebar_logout_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                contentDescription = "Log Out",
                                tint = Color(0xFFEF4444),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = Color(0xFF8FA2B0),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }

    if (showLogoPublishDialog) {
        LogoAndPublishDialog(onDismiss = { showLogoPublishDialog = false })
    }
}
