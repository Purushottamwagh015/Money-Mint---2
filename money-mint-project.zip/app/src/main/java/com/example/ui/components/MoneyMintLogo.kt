package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandBlueDark

/**
 * Money Mint Official Logo Component
 */
@Composable
fun MoneyMintLogo(
    size: Dp = 48.dp,
    showText: Boolean = false,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val clickableModifier = if (onClick != null) {
        modifier.clickable { onClick() }
    } else {
        modifier
    }

    Row(
        modifier = clickableModifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .shadow(elevation = 6.dp, shape = CircleShape)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF0F3460),
                            Color(0xFF0A2540)
                        )
                    )
                )
                .border(
                    width = 1.5.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF55EFC4),
                            Color(0xFFFFD043),
                            Color(0xFF00B894)
                        )
                    ),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_money_mint_logo),
                contentDescription = "Money Mint Official Logo",
                modifier = Modifier
                    .size(size * 0.85f)
                    .clip(CircleShape)
            )
        }

        if (showText) {
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Money",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onSurface,
                            letterSpacing = 0.5.sp
                        )
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Mint",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF00B894),
                            letterSpacing = 0.5.sp
                        )
                    )
                }
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    )
                }
            }
        }
    }
}

/**
 * Interactive Modal Dialog to inspect Logo details, brand assets & step-by-step Publishing instructions.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LogoAndPublishDialog(
    onDismiss: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var copiedText by remember { mutableStateOf<String?>(null) }

    val sharedWebUrl = "https://ais-pre-mxl5suxumr6itl3topa5a3-800580302458.asia-east1.run.app"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MoneyMintLogo(size = 36.dp)
                Column {
                    Text("Money Mint", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Brand Assets & Publishing Guide", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Large Logo Spotlight Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF0A2540)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Hero Logo Emblem
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .shadow(12.dp, CircleShape)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(Color(0xFF162447), Color(0xFF0A2540))
                                    )
                                )
                                .border(
                                    width = 2.5.dp,
                                    brush = Brush.sweepGradient(
                                        colors = listOf(
                                            Color(0xFF00B894),
                                            Color(0xFFFFD043),
                                            Color(0xFF1A73E8),
                                            Color(0xFF55EFC4),
                                            Color(0xFF00B894)
                                        )
                                    ),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_money_mint_logo),
                                contentDescription = "Official Money Mint Logo",
                                modifier = Modifier.size(92.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "Money Mint",
                            color = Color.White,
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold)
                        )
                        Text(
                            text = "Financial Intelligence & Wealth Tracking",
                            color = Color(0xFF8FA2B0),
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Palette Badges
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                "#00B894" to "Mint Emerald",
                                "#FFD043" to "Mint Gold",
                                "#1A73E8" to "Brand Blue",
                                "#0A2540" to "Deep Navy"
                            ).forEach { (hex, name) ->
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = Color(android.graphics.Color.parseColor(hex)).copy(alpha = 0.25f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(android.graphics.Color.parseColor(hex)))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(Color(android.graphics.Color.parseColor(hex)))
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(text = "$name ($hex)", color = Color.White, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Section: How to Publish This Web / Mobile App
                Text(
                    text = "How to Publish & Share This App",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Step 1: Live Cloud Preview URL (Instant sharing)
                PublishStepCard(
                    stepNumber = "1",
                    title = "Instant Live Web URL (Pre-hosted)",
                    description = "This app is hosted on Google Cloud Run and can be viewed immediately in any browser on mobile and desktop:",
                    actionLabel = "Copy Live URL",
                    actionIcon = Icons.Default.Share,
                    subtext = sharedWebUrl,
                    onAction = {
                        clipboard.setText(AnnotatedString(sharedWebUrl))
                        copiedText = "Copied Live URL to clipboard!"
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Step 2: Export Code to GitHub
                PublishStepCard(
                    stepNumber = "2",
                    title = "Push to GitHub or Download ZIP",
                    description = "In Google AI Studio, click the project menu (or Settings in the top-right) and choose 'Export to GitHub' or 'Download ZIP' to obtain the full Kotlin Android source code.",
                    actionLabel = "Ready in AI Studio",
                    actionIcon = Icons.Default.Code
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Step 3: Build APK / AAB for Android Play Store
                PublishStepCard(
                    stepNumber = "3",
                    title = "Build Release APK / Android App Bundle",
                    description = "Use standard Gradle commands: `gradle assembleRelease` or `gradle bundleRelease` to generate signed APKs or AABs ready for upload to Google Play Console.",
                    actionLabel = "Play Store Ready",
                    actionIcon = Icons.Default.PhoneAndroid
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Step 4: Deploy Web / Cloud
                PublishStepCard(
                    stepNumber = "4",
                    title = "Deploy to Firebase or Custom Domain",
                    description = "You can deploy to Firebase Hosting, Cloudflare Pages, or Google Cloud with your custom domain (e.g. moneymint.app).",
                    actionLabel = "Custom Domain",
                    actionIcon = Icons.Default.Public
                )

                if (copiedText != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = copiedText ?: "",
                        color = Color(0xFF00B894),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = BrandBlue)
            ) {
                Text("Got It")
            }
        }
    )
}

@Composable
private fun PublishStepCard(
    stepNumber: String,
    title: String,
    description: String,
    actionLabel: String,
    actionIcon: androidx.compose.ui.graphics.vector.ImageVector,
    subtext: String? = null,
    onAction: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(BrandBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stepNumber,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            )

            if (subtext != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = subtext,
                        modifier = Modifier.padding(8.dp),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = BrandBlue
                    )
                }
            }

            if (onAction != null) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onAction,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Icon(actionIcon, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(actionLabel, fontSize = 12.sp)
                }
            }
        }
    }
}
