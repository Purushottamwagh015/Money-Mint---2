package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BudgetOverview
import com.example.data.model.CategorySummary
import com.example.data.model.DateRangeFilter
import com.example.data.model.Expense
import com.example.data.model.ExpenseCategory
import com.example.ui.ChartPeriod
import com.example.ui.SpendingBarData
import com.example.ui.components.CategoryBreakdownCard
import com.example.ui.components.ExpenseTable
import com.example.ui.components.SpendingOverviewCard
import com.example.ui.components.SummaryCardsSection
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandBlueLight
import com.example.ui.utils.FormatUtils

@Composable
fun DashboardScreen(
    userName: String,
    currencySymbol: String,
    budgetOverview: BudgetOverview,
    todayExpensesAmount: Double,
    todayTransactionsCount: Int,
    chartData: List<SpendingBarData>,
    selectedChartPeriod: ChartPeriod,
    onSelectChartPeriod: (ChartPeriod) -> Unit,
    categoryBreakdown: List<CategorySummary>,
    recentExpenses: List<Expense>,
    categories: List<ExpenseCategory>,
    selectedCategory: String?,
    onSelectCategory: (String?) -> Unit,
    selectedStatus: String?,
    onSelectStatus: (String?) -> Unit,
    selectedDateRange: DateRangeFilter,
    onSelectDateRange: (DateRangeFilter) -> Unit,
    onAddExpense: () -> Unit,
    onExportCsv: () -> Unit,
    onViewExpense: (Expense) -> Unit,
    onEditExpense: (Expense) -> Unit,
    onDeleteExpense: (Expense) -> Unit,
    isCompactScreen: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Dashboard Hero / Welcome Area
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                BrandBlueLight.copy(alpha = 0.35f),
                                Color.Transparent
                            )
                        )
                    )
                    .padding(horizontal = 24.dp, vertical = 20.dp)
            ) {
                if (isCompactScreen) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Column {
                            Text(
                                text = "Good morning, $userName!",
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 24.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Here's your spending overview for today.",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 13.sp
                                )
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CalendarToday,
                                    contentDescription = null,
                                    tint = BrandBlue,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = FormatUtils.formatDate(System.currentTimeMillis(), "EEEE, MMM d, yyyy"),
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 12.sp
                                    )
                                )
                            }

                            Button(
                                onClick = onAddExpense,
                                colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("hero_add_expense_btn")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("+ Add Expense", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Good morning, $userName!",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 28.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Here's your spending overview for today.",
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 14.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CalendarToday,
                                    contentDescription = null,
                                    tint = BrandBlue,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = FormatUtils.formatDate(System.currentTimeMillis(), "EEEE, MMMM d, yyyy"),
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 13.sp
                                    )
                                )
                            }
                        }

                        Button(
                            onClick = onAddExpense,
                            colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .testTag("hero_add_expense_btn")
                                .padding(vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "+ Add Expense",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // 4 Summary Cards Section
        SummaryCardsSection(
            budgetOverview = budgetOverview,
            todayExpensesAmount = todayExpensesAmount,
            todayTransactionsCount = todayTransactionsCount,
            currencySymbol = currencySymbol
        )

        // Spending Overview and Category Breakdown
        if (isCompactScreen) {
            Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
                SpendingOverviewCard(
                    chartData = chartData,
                    selectedPeriod = selectedChartPeriod,
                    onPeriodSelect = onSelectChartPeriod,
                    currencySymbol = currencySymbol
                )
                CategoryBreakdownCard(
                    categories = categoryBreakdown,
                    currencySymbol = currencySymbol
                )
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                SpendingOverviewCard(
                    chartData = chartData,
                    selectedPeriod = selectedChartPeriod,
                    onPeriodSelect = onSelectChartPeriod,
                    currencySymbol = currencySymbol,
                    modifier = Modifier.weight(1.5f)
                )
                CategoryBreakdownCard(
                    categories = categoryBreakdown,
                    currencySymbol = currencySymbol,
                    modifier = Modifier.weight(1.0f)
                )
            }
        }

        // Recent Expenses Table
        ExpenseTable(
            expenses = recentExpenses,
            categories = categories,
            currencySymbol = currencySymbol,
            selectedCategory = selectedCategory,
            onSelectCategory = onSelectCategory,
            selectedStatus = selectedStatus,
            onSelectStatus = onSelectStatus,
            selectedDateRange = selectedDateRange,
            onSelectDateRange = onSelectDateRange,
            onAddExpense = onAddExpense,
            onExportCsv = onExportCsv,
            onViewExpense = onViewExpense,
            onEditExpense = onEditExpense,
            onDeleteExpense = onDeleteExpense,
            isCompactScreen = isCompactScreen,
            title = "Recent Expenses"
        )
    }
}
