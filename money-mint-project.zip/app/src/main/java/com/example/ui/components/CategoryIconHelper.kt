package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

object CategoryIconHelper {
    fun getIcon(iconKey: String): ImageVector {
        return when (iconKey.lowercase()) {
            "food", "food & dining", "restaurant" -> Icons.Default.Restaurant
            "transport", "transportation", "bus", "car" -> Icons.Default.DirectionsBus
            "shopping", "shop" -> Icons.Default.ShoppingBag
            "bills", "bills & utilities", "utilities" -> Icons.Default.Receipt
            "entertainment", "movie" -> Icons.Default.Movie
            "education", "school", "books" -> Icons.Default.School
            "healthcare", "health", "hospital" -> Icons.Default.LocalHospital
            else -> Icons.Default.Category
        }
    }

    fun parseColor(hex: String, defaultColor: Color = Color(0xFF0878B8)): Color {
        return try {
            val cleanHex = hex.removePrefix("#")
            val colorLong = if (cleanHex.length == 6) {
                "FF$cleanHex".toLong(16)
            } else {
                cleanHex.toLong(16)
            }
            Color(colorLong)
        } catch (_: Exception) {
            defaultColor
        }
    }
}
