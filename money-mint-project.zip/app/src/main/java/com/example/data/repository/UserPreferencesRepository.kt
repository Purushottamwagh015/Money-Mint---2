package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class UserPreferencesRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("moneymint_prefs", Context.MODE_PRIVATE)

    private val _isLoggedIn = MutableStateFlow(prefs.getBoolean("is_logged_in", false))
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _userName = MutableStateFlow(prefs.getString("user_name", "Purushottam Wagh") ?: "Purushottam Wagh")
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _userEmail = MutableStateFlow(prefs.getString("user_email", "purushottamwagh016@gmail.com") ?: "purushottamwagh016@gmail.com")
    val userEmail: StateFlow<String> = _userEmail.asStateFlow()

    private val _currencySymbol = MutableStateFlow(prefs.getString("currency_symbol", "₹") ?: "₹")
    val currencySymbol: StateFlow<String> = _currencySymbol.asStateFlow()

    private val _monthlyBudget = MutableStateFlow(prefs.getFloat("monthly_budget", 40000.0f).toDouble())
    val monthlyBudget: StateFlow<Double> = _monthlyBudget.asStateFlow()

    private val _themeMode = MutableStateFlow(prefs.getString("theme_mode", "light") ?: "light") // "light", "dark", "system"
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _budgetAlerts = MutableStateFlow(prefs.getBoolean("budget_alerts", true))
    val budgetAlerts: StateFlow<Boolean> = _budgetAlerts.asStateFlow()

    private val _dailyReminders = MutableStateFlow(prefs.getBoolean("daily_reminders", true))
    val dailyReminders: StateFlow<Boolean> = _dailyReminders.asStateFlow()

    private val _monthlySummaries = MutableStateFlow(prefs.getBoolean("monthly_summaries", true))
    val monthlySummaries: StateFlow<Boolean> = _monthlySummaries.asStateFlow()

    fun login(email: String, name: String? = null) {
        val finalName = if (!name.isNullOrBlank()) name else email.substringBefore("@").replace(".", " ").replaceFirstChar { it.uppercase() }
        prefs.edit()
            .putBoolean("is_logged_in", true)
            .putString("user_email", email)
            .putString("user_name", finalName)
            .apply()
        _isLoggedIn.value = true
        _userEmail.value = email
        _userName.value = finalName
    }

    fun logout() {
        prefs.edit().putBoolean("is_logged_in", false).apply()
        _isLoggedIn.value = false
    }

    fun register(name: String, email: String, currency: String) {
        prefs.edit()
            .putBoolean("is_logged_in", true)
            .putString("user_name", name)
            .putString("user_email", email)
            .putString("currency_symbol", currency)
            .apply()
        _isLoggedIn.value = true
        _userName.value = name
        _userEmail.value = email
        _currencySymbol.value = currency
    }

    fun updateProfile(name: String, email: String) {
        prefs.edit().putString("user_name", name).putString("user_email", email).apply()
        _userName.value = name
        _userEmail.value = email
    }

    fun updateCurrency(symbol: String) {
        prefs.edit().putString("currency_symbol", symbol).apply()
        _currencySymbol.value = symbol
    }

    fun updateMonthlyBudget(budget: Double) {
        prefs.edit().putFloat("monthly_budget", budget.toFloat()).apply()
        _monthlyBudget.value = budget
    }

    fun updateThemeMode(mode: String) {
        prefs.edit().putString("theme_mode", mode).apply()
        _themeMode.value = mode
    }

    fun updateNotificationSettings(alerts: Boolean, daily: Boolean, monthly: Boolean) {
        prefs.edit()
            .putBoolean("budget_alerts", alerts)
            .putBoolean("daily_reminders", daily)
            .putBoolean("monthly_summaries", monthly)
            .apply()
        _budgetAlerts.value = alerts
        _dailyReminders.value = daily
        _monthlySummaries.value = monthly
    }
}
