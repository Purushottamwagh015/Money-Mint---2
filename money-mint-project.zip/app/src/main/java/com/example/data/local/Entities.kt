package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.Expense
import com.example.data.model.ExpenseCategory
import com.example.data.model.ExpenseStatus
import com.example.data.model.PaymentMethod

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val amount: Double,
    val category: String,
    val dateMillis: Long,
    val paymentMethod: String,
    val status: String,
    val notes: String = "",
    val receiptUri: String? = null
) {
    fun toDomain(): Expense {
        return Expense(
            id = id,
            title = title,
            amount = amount,
            category = category,
            dateMillis = dateMillis,
            paymentMethod = PaymentMethod.fromString(paymentMethod),
            status = ExpenseStatus.fromString(status),
            notes = notes,
            receiptUri = receiptUri
        )
    }

    companion object {
        fun fromDomain(expense: Expense): ExpenseEntity {
            return ExpenseEntity(
                id = expense.id,
                title = expense.title,
                amount = expense.amount,
                category = expense.category,
                dateMillis = expense.dateMillis,
                paymentMethod = expense.paymentMethod.name,
                status = expense.status.name,
                notes = expense.notes,
                receiptUri = expense.receiptUri
            )
        }
    }
}

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val iconKey: String,
    val colorHex: String,
    val monthlyBudget: Double = 0.0,
    val isCustom: Boolean = false
) {
    fun toDomain(): ExpenseCategory {
        return ExpenseCategory(
            id = id,
            name = name,
            iconKey = iconKey,
            colorHex = colorHex,
            monthlyBudget = monthlyBudget,
            isCustom = isCustom
        )
    }

    companion object {
        fun fromDomain(cat: ExpenseCategory): CategoryEntity {
            return CategoryEntity(
                id = cat.id,
                name = cat.name,
                iconKey = cat.iconKey,
                colorHex = cat.colorHex,
                monthlyBudget = cat.monthlyBudget,
                isCustom = cat.isCustom
            )
        }
    }
}
