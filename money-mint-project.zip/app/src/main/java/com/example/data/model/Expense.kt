package com.example.data.model

data class Expense(
    val id: Long = 0,
    val title: String,
    val amount: Double,
    val category: String,
    val dateMillis: Long,
    val paymentMethod: PaymentMethod = PaymentMethod.UPI,
    val status: ExpenseStatus = ExpenseStatus.COMPLETED,
    val notes: String = "",
    val receiptUri: String? = null
)

data class ExpenseCategory(
    val id: Long = 0,
    val name: String,
    val iconKey: String, // e.g. "food", "transport", "shopping", "bills", "entertainment", "education", "healthcare", "other"
    val colorHex: String,
    val monthlyBudget: Double = 0.0,
    val isCustom: Boolean = false
)

data class CategorySummary(
    val categoryName: String,
    val iconKey: String,
    val colorHex: String,
    val totalAmount: Double,
    val percentage: Float,
    val transactionCount: Int,
    val budget: Double
)

data class BudgetOverview(
    val totalBudget: Double,
    val totalSpent: Double,
    val remainingBudget: Double,
    val percentUsed: Float
)
