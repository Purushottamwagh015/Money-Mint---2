package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.CategoryEntity
import com.example.data.local.ExpenseEntity
import com.example.data.local.InitialData
import com.example.data.model.Expense
import com.example.data.model.ExpenseCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExpenseRepository(private val database: AppDatabase) {
    private val expenseDao = database.expenseDao()
    private val categoryDao = database.categoryDao()

    val allExpenses: Flow<List<Expense>> = expenseDao.getAllExpenses().map { list ->
        list.map { it.toDomain() }
    }

    val allCategories: Flow<List<ExpenseCategory>> = categoryDao.getAllCategories().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun initializeIfNeeded() = withContext(Dispatchers.IO) {
        val categoryCount = categoryDao.getCount()
        if (categoryCount == 0) {
            val catEntities = InitialData.defaultCategories.map { CategoryEntity.fromDomain(it) }
            categoryDao.insertAll(catEntities)
            val initialExpenses = InitialData.getInitialExpenses()
            expenseDao.insertAll(initialExpenses)
        }
    }

    suspend fun addExpense(expense: Expense): Long = withContext(Dispatchers.IO) {
        val entity = ExpenseEntity.fromDomain(expense)
        expenseDao.insertExpense(entity)
    }

    suspend fun updateExpense(expense: Expense) = withContext(Dispatchers.IO) {
        val entity = ExpenseEntity.fromDomain(expense)
        expenseDao.updateExpense(entity)
    }

    suspend fun deleteExpense(id: Long) = withContext(Dispatchers.IO) {
        expenseDao.deleteExpenseById(id)
    }

    suspend fun addCategory(category: ExpenseCategory): Long = withContext(Dispatchers.IO) {
        val entity = CategoryEntity.fromDomain(category)
        categoryDao.insertCategory(entity)
    }

    suspend fun updateCategory(category: ExpenseCategory) = withContext(Dispatchers.IO) {
        val entity = CategoryEntity.fromDomain(category)
        categoryDao.updateCategory(entity)
    }

    suspend fun deleteCategory(id: Long) = withContext(Dispatchers.IO) {
        categoryDao.deleteCategoryById(id)
    }

    suspend fun resetToSampleData() = withContext(Dispatchers.IO) {
        expenseDao.clearAll()
        categoryDao.clearAll()
        val catEntities = InitialData.defaultCategories.map { CategoryEntity.fromDomain(it) }
        categoryDao.insertAll(catEntities)
        val initialExpenses = InitialData.getInitialExpenses()
        expenseDao.insertAll(initialExpenses)
    }

    fun exportToCsv(expenses: List<Expense>, currencySymbol: String): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val sb = StringBuilder()
        sb.append("ID,Date,Description,Category,Payment Method,Status,Amount ($currencySymbol),Notes\n")
        for (e in expenses) {
            val dateStr = sdf.format(Date(e.dateMillis))
            val escapedDesc = "\"" + e.title.replace("\"", "\"\"") + "\""
            val escapedNotes = "\"" + e.notes.replace("\"", "\"\"") + "\""
            sb.append("${e.id},$dateStr,$escapedDesc,\"${e.category}\",\"${e.paymentMethod.displayName}\",\"${e.status.displayName}\",${e.amount},$escapedNotes\n")
        }
        return sb.toString()
    }
}
