package com.example.data.local

import com.example.data.model.ExpenseCategory
import java.util.Calendar

object InitialData {
    val defaultCategories = listOf(
        ExpenseCategory(
            name = "Food & Dining",
            iconKey = "food",
            colorHex = "#0878B8",
            monthlyBudget = 8000.0
        ),
        ExpenseCategory(
            name = "Transportation",
            iconKey = "transport",
            colorHex = "#25A56A",
            monthlyBudget = 5000.0
        ),
        ExpenseCategory(
            name = "Shopping",
            iconKey = "shopping",
            colorHex = "#E4A72C",
            monthlyBudget = 6000.0
        ),
        ExpenseCategory(
            name = "Bills & Utilities",
            iconKey = "bills",
            colorHex = "#6C5CE7",
            monthlyBudget = 7000.0
        ),
        ExpenseCategory(
            name = "Entertainment",
            iconKey = "entertainment",
            colorHex = "#FD79A8",
            monthlyBudget = 4000.0
        ),
        ExpenseCategory(
            name = "Education",
            iconKey = "education",
            colorHex = "#0984E3",
            monthlyBudget = 5000.0
        ),
        ExpenseCategory(
            name = "Healthcare",
            iconKey = "healthcare",
            colorHex = "#D9534F",
            monthlyBudget = 3000.0
        ),
        ExpenseCategory(
            name = "Other",
            iconKey = "other",
            colorHex = "#636E72",
            monthlyBudget = 2000.0
        )
    )

    fun getInitialExpenses(): List<ExpenseEntity> {
        val cal = Calendar.getInstance()
        val now = cal.timeInMillis

        // Helper to set day relative to current month (Sept 2026)
        fun timeForDay(dayOfMonth: Int, hour: Int, minute: Int): Long {
            val c = Calendar.getInstance()
            c.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            c.set(Calendar.HOUR_OF_DAY, hour)
            c.set(Calendar.MINUTE, minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            return c.timeInMillis
        }

        val currentDay = cal.get(Calendar.DAY_OF_MONTH)

        // Today's 5 transactions summing to ₹1,240
        val todayExpenses = listOf(
            ExpenseEntity(
                title = "Grocery Shopping",
                amount = 850.0,
                category = "Food & Dining",
                dateMillis = timeForDay(currentDay, 10, 30),
                paymentMethod = "UPI",
                status = "COMPLETED",
                notes = "Weekly fresh fruits, veggies, and milk"
            ),
            ExpenseEntity(
                title = "Morning Coffee & Snack",
                amount = 120.0,
                category = "Food & Dining",
                dateMillis = timeForDay(currentDay, 8, 45),
                paymentMethod = "UPI",
                status = "COMPLETED",
                notes = "Quick coffee before morning team standup"
            ),
            ExpenseEntity(
                title = "Metro Ticket",
                amount = 50.0,
                category = "Transportation",
                dateMillis = timeForDay(currentDay, 9, 15),
                paymentMethod = "UPI",
                status = "COMPLETED",
                notes = "Round trip smart card tap"
            ),
            ExpenseEntity(
                title = "College Canteen Lunch",
                amount = 160.0,
                category = "Food & Dining",
                dateMillis = timeForDay(currentDay, 13, 10),
                paymentMethod = "CASH",
                status = "COMPLETED",
                notes = "Thali combo at canteen"
            ),
            ExpenseEntity(
                title = "Stationery Pen Refill",
                amount = 60.0,
                category = "Education",
                dateMillis = timeForDay(currentDay, 16, 20),
                paymentMethod = "CASH",
                status = "COMPLETED",
                notes = "Ballpoint pens and sticky note pad"
            )
        )

        // Past transactions for this month summing to 24,680 - 1,240 = 23,440
        val pastExpenses = listOf(
            ExpenseEntity(
                title = "College Bus Pass",
                amount = 1200.0,
                category = "Transportation",
                dateMillis = timeForDay(maxOf(1, currentDay - 1), 11, 0),
                paymentMethod = "UPI",
                status = "COMPLETED",
                notes = "Semester monthly pass renewal"
            ),
            ExpenseEntity(
                title = "Internet Bill",
                amount = 799.0,
                category = "Bills & Utilities",
                dateMillis = timeForDay(maxOf(1, currentDay - 2), 14, 30),
                paymentMethod = "DEBIT_CARD",
                status = "COMPLETED",
                notes = "Fiber broadband 200Mbps monthly plan"
            ),
            ExpenseEntity(
                title = "Stationery & Textbooks",
                amount = 340.0,
                category = "Education",
                dateMillis = timeForDay(maxOf(1, currentDay - 3), 17, 15),
                paymentMethod = "CASH",
                status = "COMPLETED",
                notes = "Project binder and spiral notebook"
            ),
            ExpenseEntity(
                title = "Movie Tickets & Popcorn",
                amount = 450.0,
                category = "Entertainment",
                dateMillis = timeForDay(maxOf(1, currentDay - 4), 20, 0),
                paymentMethod = "UPI",
                status = "COMPLETED",
                notes = "Weekend cinema evening"
            ),
            ExpenseEntity(
                title = "Electricity Bill",
                amount = 2350.0,
                category = "Bills & Utilities",
                dateMillis = timeForDay(maxOf(1, currentDay - 5), 10, 15),
                paymentMethod = "UPI",
                status = "COMPLETED",
                notes = "State power utility monthly consumption"
            ),
            ExpenseEntity(
                title = "Weekly Supermarket Run",
                amount = 2840.0,
                category = "Food & Dining",
                dateMillis = timeForDay(maxOf(1, currentDay - 6), 18, 45),
                paymentMethod = "CREDIT_CARD",
                status = "COMPLETED",
                notes = "Kitchen staples, oils, dry fruits, and spices"
            ),
            ExpenseEntity(
                title = "Clothes & Sneakers",
                amount = 3720.0,
                category = "Shopping",
                dateMillis = timeForDay(maxOf(1, currentDay - 7), 16, 0),
                paymentMethod = "DEBIT_CARD",
                status = "COMPLETED",
                notes = "New running shoes and casual shirt"
            ),
            ExpenseEntity(
                title = "Mobile Recharge",
                amount = 499.0,
                category = "Bills & Utilities",
                dateMillis = timeForDay(maxOf(1, currentDay - 8), 12, 10),
                paymentMethod = "UPI",
                status = "COMPLETED",
                notes = "84-day prepaid data plan"
            ),
            ExpenseEntity(
                title = "Pharmacy & Vitamins",
                amount = 1150.0,
                category = "Healthcare",
                dateMillis = timeForDay(maxOf(1, currentDay - 9), 19, 30),
                paymentMethod = "UPI",
                status = "COMPLETED",
                notes = "Multivitamins and first aid refill"
            ),
            ExpenseEntity(
                title = "Dinner with Friends",
                amount = 2280.0,
                category = "Food & Dining",
                dateMillis = timeForDay(maxOf(1, currentDay - 10), 21, 15),
                paymentMethod = "UPI",
                status = "COMPLETED",
                notes = "Weekend get-together barbecue"
            ),
            ExpenseEntity(
                title = "Fuel / Petrol",
                amount = 1650.0,
                category = "Transportation",
                dateMillis = timeForDay(maxOf(1, currentDay - 11), 9, 30),
                paymentMethod = "CREDIT_CARD",
                status = "COMPLETED",
                notes = "Full vehicle tank fill"
            ),
            ExpenseEntity(
                title = "Streaming Services",
                amount = 649.0,
                category = "Entertainment",
                dateMillis = timeForDay(maxOf(1, currentDay - 12), 15, 0),
                paymentMethod = "CREDIT_CARD",
                status = "COMPLETED",
                notes = "Monthly entertainment family plan"
            ),
            ExpenseEntity(
                title = "Online Course Subscription",
                amount = 2400.0,
                category = "Education",
                dateMillis = timeForDay(maxOf(1, currentDay - 14), 11, 45),
                paymentMethod = "DEBIT_CARD",
                status = "COMPLETED",
                notes = "Mobile App Architecture Masterclass"
            ),
            ExpenseEntity(
                title = "Dental Checkup",
                amount = 1200.0,
                category = "Healthcare",
                dateMillis = timeForDay(maxOf(1, currentDay - 16), 17, 0),
                paymentMethod = "CASH",
                status = "COMPLETED",
                notes = "Routine dental hygiene and polish"
            ),
            ExpenseEntity(
                title = "Apartment Water Bill",
                amount = 380.0,
                category = "Bills & Utilities",
                dateMillis = timeForDay(maxOf(1, currentDay - 18), 10, 0),
                paymentMethod = "UPI",
                status = "COMPLETED",
                notes = "Society water maintenance dues"
            ),
            ExpenseEntity(
                title = "Cab Rides",
                amount = 1280.0,
                category = "Transportation",
                dateMillis = timeForDay(maxOf(1, currentDay - 20), 22, 30),
                paymentMethod = "UPI",
                status = "COMPLETED",
                notes = "Late commute from airport"
            ),
            ExpenseEntity(
                title = "Books & Supplies",
                amount = 832.0,
                category = "Other",
                dateMillis = timeForDay(maxOf(1, currentDay - 21), 14, 0),
                paymentMethod = "UPI",
                status = "COMPLETED",
                notes = "Desk lamp and productivity planner"
            )
        )

        return todayExpenses + pastExpenses
    }
}
