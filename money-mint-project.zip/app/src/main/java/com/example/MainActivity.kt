package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.model.Expense
import com.example.data.model.ExpenseCategory
import com.example.data.repository.ExpenseRepository
import com.example.data.repository.UserPreferencesRepository
import com.example.ui.AppDestination
import com.example.ui.MainViewModel
import com.example.ui.components.AddEditCategoryDialog
import com.example.ui.components.AddEditExpenseDialog
import com.example.ui.components.ExpenseDetailsModal
import com.example.ui.components.GenericDeleteConfirmDialog
import com.example.ui.components.SetBudgetDialog
import com.example.ui.components.SpendWiseBottomBar
import com.example.ui.components.SpendWiseSidebar
import com.example.ui.components.SpendWiseTopHeader
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.BudgetsScreen
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ExpensesScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext)
        val expenseRepository = ExpenseRepository(database)
        val userPreferencesRepository = UserPreferencesRepository(applicationContext)
        val viewModelFactory = MainViewModel.Factory(expenseRepository, userPreferencesRepository)

        setContent {
            val viewModel: MainViewModel = viewModel(factory = viewModelFactory)
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            val isSystemDark = isSystemInDarkTheme()
            val isDarkTheme = when (uiState.themeMode) {
                "dark" -> true
                "light" -> false
                else -> isSystemDark
            }

            MyApplicationTheme(darkTheme = isDarkTheme) {
                if (!uiState.isLoggedIn) {
                    LoginScreen(
                        initialEmail = uiState.userEmail,
                        onLoginSuccess = { email, name ->
                            viewModel.login(email, name)
                        },
                        onRegisterSuccess = { name, email, currency ->
                            viewModel.register(name, email, currency)
                        }
                    )
                } else {
                    SpendWiseApp(
                        viewModel = viewModel,
                        isDarkTheme = isDarkTheme,
                        onLogout = { viewModel.logout() }
                    )
                }
            }
        }
    }
}

@Composable
fun SpendWiseApp(
    viewModel: MainViewModel,
    isDarkTheme: Boolean,
    onLogout: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    // Dialog States
    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var expenseToEdit by remember { mutableStateOf<Expense?>(null) }
    var selectedExpenseForDetails by remember { mutableStateOf<Expense?>(null) }
    var expenseToDelete by remember { mutableStateOf<Expense?>(null) }
    var showBudgetDialog by remember { mutableStateOf(false) }
    var showAddCategoryDialog by remember { mutableStateOf(false) }
    var categoryToEdit by remember { mutableStateOf<ExpenseCategory?>(null) }
    var categoryToDelete by remember { mutableStateOf<ExpenseCategory?>(null) }

    // Listen for events / messages
    fun showToast(msg: String) {
        scope.launch {
            snackbarHostState.showSnackbar(msg)
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isCompactScreen = maxWidth < 840.dp

        val navigateTo: (AppDestination) -> Unit = { dest ->
            if (dest == AppDestination.ADD_EXPENSE) {
                expenseToEdit = null
                showAddExpenseDialog = true
            } else {
                viewModel.onNavigate(dest)
            }
            if (isCompactScreen && drawerState.isOpen) {
                scope.launch { drawerState.close() }
            }
        }

        val contentComposable: @Composable (Modifier) -> Unit = { contentModifier ->
            Box(
                modifier = contentModifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                when (uiState.currentDestination) {
                    AppDestination.DASHBOARD -> {
                        DashboardScreen(
                            userName = uiState.userName,
                            currencySymbol = uiState.currencySymbol,
                            budgetOverview = uiState.budgetOverview,
                            todayExpensesAmount = uiState.todayExpensesAmount,
                            todayTransactionsCount = uiState.todayTransactionsCount,
                            chartData = uiState.spendingChartData,
                            selectedChartPeriod = uiState.selectedChartPeriod,
                            onSelectChartPeriod = { viewModel.setChartPeriod(it) },
                            categoryBreakdown = uiState.categorySummaries,
                            recentExpenses = uiState.filteredExpenses.take(7),
                            categories = uiState.categories,
                            selectedCategory = uiState.selectedCategoryFilter,
                            onSelectCategory = { viewModel.filterByCategory(it) },
                            selectedStatus = uiState.selectedStatusFilter,
                            onSelectStatus = { viewModel.filterByStatus(it) },
                            selectedDateRange = uiState.selectedDateRange,
                            onSelectDateRange = { viewModel.setDateRangeFilter(it) },
                            onAddExpense = {
                                expenseToEdit = null
                                showAddExpenseDialog = true
                            },
                            onExportCsv = {
                                val csv = viewModel.exportCsv()
                                showToast("Exported ${uiState.expenses.size} expenses to CSV")
                            },
                            onViewExpense = { selectedExpenseForDetails = it },
                            onEditExpense = {
                                expenseToEdit = it
                                showAddExpenseDialog = true
                            },
                            onDeleteExpense = { expenseToDelete = it },
                            isCompactScreen = isCompactScreen
                        )
                    }
                    AppDestination.MY_EXPENSES, AppDestination.ADD_EXPENSE -> {
                        ExpensesScreen(
                            expenses = uiState.filteredExpenses,
                            categories = uiState.categories,
                            currencySymbol = uiState.currencySymbol,
                            selectedCategory = uiState.selectedCategoryFilter,
                            onSelectCategory = { viewModel.filterByCategory(it) },
                            selectedStatus = uiState.selectedStatusFilter,
                            onSelectStatus = { viewModel.filterByStatus(it) },
                            selectedDateRange = uiState.selectedDateRange,
                            onSelectDateRange = { viewModel.setDateRangeFilter(it) },
                            onAddExpense = {
                                expenseToEdit = null
                                showAddExpenseDialog = true
                            },
                            onExportCsv = {
                                val csv = viewModel.exportCsv()
                                showToast("Exported ${uiState.expenses.size} expenses to CSV")
                            },
                            onViewExpense = { selectedExpenseForDetails = it },
                            onEditExpense = {
                                expenseToEdit = it
                                showAddExpenseDialog = true
                            },
                            onDeleteExpense = { expenseToDelete = it },
                            isCompactScreen = isCompactScreen
                        )
                    }
                    AppDestination.BUDGETS -> {
                        BudgetsScreen(
                            budgetOverview = uiState.budgetOverview,
                            categories = uiState.categories,
                            categorySummaries = uiState.categorySummaries,
                            currencySymbol = uiState.currencySymbol,
                            onSetOverallBudget = { showBudgetDialog = true },
                            onEditCategoryBudget = {
                                categoryToEdit = it
                                showAddCategoryDialog = true
                            },
                            isCompactScreen = isCompactScreen
                        )
                    }
                    AppDestination.ANALYTICS -> {
                        AnalyticsScreen(
                            expenses = uiState.expenses,
                            categorySummaries = uiState.categorySummaries,
                            currencySymbol = uiState.currencySymbol,
                            isCompactScreen = isCompactScreen
                        )
                    }
                    AppDestination.CATEGORIES -> {
                        CategoriesScreen(
                            categories = uiState.categories,
                            categorySummaries = uiState.categorySummaries,
                            currencySymbol = uiState.currencySymbol,
                            onAddCategory = {
                                categoryToEdit = null
                                showAddCategoryDialog = true
                            },
                            onEditCategory = {
                                categoryToEdit = it
                                showAddCategoryDialog = true
                            },
                            onDeleteCategory = { categoryToDelete = it },
                            isCompactScreen = isCompactScreen
                        )
                    }
                    AppDestination.REPORTS -> {
                        ReportsScreen(
                            expenses = uiState.expenses,
                            categorySummaries = uiState.categorySummaries,
                            budgetOverview = uiState.budgetOverview,
                            currencySymbol = uiState.currencySymbol,
                            onExportCsv = {
                                val csv = viewModel.exportCsv()
                                showToast("Financial statement exported as CSV")
                            },
                            onNavigate = navigateTo,
                            isCompactScreen = isCompactScreen
                        )
                    }
                    AppDestination.SETTINGS -> {
                        SettingsScreen(
                            userName = uiState.userName,
                            userEmail = uiState.userEmail,
                            currencySymbol = uiState.currencySymbol,
                            themeMode = uiState.themeMode,
                            budgetAlerts = uiState.budgetAlerts,
                            dailyReminders = uiState.dailyReminders,
                            monthlySummaries = uiState.monthlySummaries,
                            onUpdateProfile = { name, email ->
                                viewModel.updateProfile(name, email)
                                showToast("Profile updated successfully")
                            },
                            onUpdateCurrency = { symbol ->
                                viewModel.updateCurrency(symbol)
                                showToast("Currency set to $symbol")
                            },
                            onToggleTheme = {
                                viewModel.toggleTheme()
                            },
                            onUpdateNotifications = { alerts, reminders, summaries ->
                                viewModel.updateNotifications(alerts, reminders, summaries)
                                showToast("Preferences updated")
                            },
                            onResetData = {
                                viewModel.resetSampleData()
                                showToast("Sample demo data restored")
                            },
                            onNavigate = navigateTo,
                            onLogout = onLogout
                        )
                    }
                }
            }
        }

        if (isCompactScreen) {
            // Mobile Layout: Modal Drawer + Top Header + Content + Bottom Bar
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = Color.Transparent,
                        modifier = Modifier.width(260.dp)
                    ) {
                        SpendWiseSidebar(
                            currentDestination = uiState.currentDestination,
                            userName = uiState.userName,
                            userEmail = uiState.userEmail,
                            onNavigate = navigateTo,
                            onLogout = onLogout
                        )
                    }
                }
            ) {
                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        SpendWiseTopHeader(
                            searchQuery = uiState.searchQuery,
                            onSearchChange = { viewModel.setSearchQuery(it) },
                            userName = uiState.userName,
                            isDarkMode = isDarkTheme,
                            onToggleTheme = { viewModel.toggleTheme() },
                            onNavigate = navigateTo,
                            isCompactScreen = true,
                            onOpenDrawer = {
                                scope.launch { drawerState.open() }
                            },
                            onLogout = onLogout
                        )
                    },
                    bottomBar = {
                        SpendWiseBottomBar(
                            currentDestination = uiState.currentDestination,
                            onNavigate = navigateTo
                        )
                    },
                    floatingActionButton = {
                        FloatingActionButton(
                            onClick = {
                                expenseToEdit = null
                                showAddExpenseDialog = true
                            },
                            containerColor = BrandBlue,
                            contentColor = Color.White,
                            modifier = Modifier.testTag("fab_add_expense")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add Expense")
                        }
                    }
                ) { paddingValues ->
                    contentComposable(Modifier.padding(paddingValues))
                }
            }
        } else {
            // Desktop / Tablet Layout: Permanent Sidebar + Header + Content
            Row(modifier = Modifier.fillMaxSize()) {
                SpendWiseSidebar(
                    currentDestination = uiState.currentDestination,
                    userName = uiState.userName,
                    userEmail = uiState.userEmail,
                    onNavigate = navigateTo,
                    onLogout = onLogout
                )

                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        SpendWiseTopHeader(
                            searchQuery = uiState.searchQuery,
                            onSearchChange = { viewModel.setSearchQuery(it) },
                            userName = uiState.userName,
                            isDarkMode = isDarkTheme,
                            onToggleTheme = { viewModel.toggleTheme() },
                            onNavigate = navigateTo,
                            isCompactScreen = false,
                            onOpenDrawer = {},
                            onLogout = onLogout
                        )
                    },
                    modifier = Modifier.weight(1f)
                ) { paddingValues ->
                    contentComposable(Modifier.padding(paddingValues))
                }
            }
        }
    }

    // Modal Dialogs
    if (showAddExpenseDialog) {
        AddEditExpenseDialog(
            initialExpense = expenseToEdit,
            categories = uiState.categories,
            currencySymbol = uiState.currencySymbol,
            onDismiss = {
                showAddExpenseDialog = false
                expenseToEdit = null
            },
            onSave = { id, title, amount, category, dateMillis, method, status, notes ->
                viewModel.saveExpense(
                    id = id,
                    title = title,
                    amount = amount,
                    category = category,
                    dateMillis = dateMillis,
                    paymentMethod = method,
                    status = status,
                    notes = notes
                )
                showAddExpenseDialog = false
                expenseToEdit = null
                showToast(if (id == 0L) "Expense recorded" else "Expense updated")
            }
        )
    }

    selectedExpenseForDetails?.let { expense ->
        ExpenseDetailsModal(
            expense = expense,
            currencySymbol = uiState.currencySymbol,
            onDismiss = { selectedExpenseForDetails = null },
            onEdit = {
                selectedExpenseForDetails = null
                expenseToEdit = expense
                showAddExpenseDialog = true
            },
            onDelete = {
                selectedExpenseForDetails = null
                expenseToDelete = expense
            }
        )
    }

    expenseToDelete?.let { expense ->
        GenericDeleteConfirmDialog(
            title = "Delete Expense?",
            message = "Are you sure you want to delete \"${expense.title}\"? This action cannot be undone.",
            onDismiss = { expenseToDelete = null },
            onConfirm = {
                viewModel.deleteExpense(expense)
                expenseToDelete = null
                showToast("Expense removed")
            }
        )
    }

    if (showBudgetDialog) {
        SetBudgetDialog(
            currentBudget = uiState.budgetOverview.totalBudget,
            currencySymbol = uiState.currencySymbol,
            onDismiss = { showBudgetDialog = false },
            onSave = { newBudget ->
                viewModel.updateMonthlyBudget(newBudget)
                showBudgetDialog = false
                showToast("Monthly budget updated")
            }
        )
    }

    if (showAddCategoryDialog) {
        AddEditCategoryDialog(
            initialCategory = categoryToEdit,
            currencySymbol = uiState.currencySymbol,
            onDismiss = {
                showAddCategoryDialog = false
                categoryToEdit = null
            },
            onSave = { name, iconKey, colorHex, budget ->
                viewModel.saveCategory(
                    id = categoryToEdit?.id ?: 0L,
                    name = name,
                    iconKey = iconKey,
                    colorHex = colorHex,
                    budget = budget
                )
                showAddCategoryDialog = false
                categoryToEdit = null
                showToast("Category saved")
            }
        )
    }

    categoryToDelete?.let { category ->
        GenericDeleteConfirmDialog(
            title = "Delete Category?",
            message = "Are you sure you want to delete category \"${category.name}\"?",
            onDismiss = { categoryToDelete = null },
            onConfirm = {
                viewModel.deleteCategory(category)
                categoryToDelete = null
                showToast("Category deleted")
            }
        )
    }
}
